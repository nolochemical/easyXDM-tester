Pre-requirements:
 * Apache Ant.
 * Java runtime 1.5+.

How to use the build process in your project:
 * Copy the js_build_tools.jar and yuicompressor.jar files to your project.
 * Copy the example/build.xml file to your project.
 * Modify the build.xml to match your needs.
