ext-doc is a ExtJS-style JavaScript comments processor

Currently it includes only one sample (please, read sample/README.txt)
and one XSLT-based template (template/ext). 

Requires Java 1.6 to run.

Quick Start:

1) Download ExtJS source code
2) Create "sample/ext" folder
3) Copy ExtJS source to "samplel/ext" (ex.: sample/ext/source/core/Ext.js)
4) Run sample/ext-doc.bat ("output" directory will be created)
5) Copy "output" to http server


 Andrey Zubkov aka oxymoron

